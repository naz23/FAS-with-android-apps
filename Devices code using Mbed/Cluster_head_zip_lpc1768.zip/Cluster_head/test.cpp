#include "mbed.h"
#include "xbee.h" // Include for xbee code
#include "C12832_lcd.h" // Include for LCD code
#include "HTTPClient.h"
#include "EthernetInterface.h"


xbee xbee1(p9,p10,p11); //Initalise xbee_lib varName(rx,tx,reset)
DigitalOut rst1(p30);
DigitalOut led(LED1);
Serial pc(USBTX, USBRX); //Initalise PC serial comms
C12832_LCD lcd; //Initialize LCD Screen

//Code to send strings acsross xbee with xbee.h
//Code should be on the End Device 
int main()
{
     static const char*          mbedIp       = "192.168.137.102";  //IP
     static const char*          mbedMask     = "255.255.255.0";  // Mask
     static const char*          mbedGateway  = "192.168.137.1";    //Gateway
 
EthernetInterface eth;
eth.init(mbedIp,mbedMask,mbedGateway); //Use  these parameters for static IP
eth.connect();
    printf("IP Address is %s\n", eth.getIPAddress());
    // reset the xbees (at least 200ns)
    rst1 = 0;
    wait_ms(1); 
    rst1 = 1;
    wait_ms(1);
    
    //Establish a variable to receive data from End Device
    //Max buffer is 202
    char receiveData[3]; 
    
    //Setup LCD screen
    lcd.cls();      
    lcd.locate(0,1);


HTTPClient http;
    
char str[512];
char ret;
const char *id = "3";

   
    
    while(1) {
        //Recieve data from Xbee
        //Second argument is how many characters to read
        //If zero it will read sizeof(firstArg)
        xbee1.RecieveData(receiveData,3);
        led = 1;
        wait(5.0);
        led = 0;
         char *temp = receiveData;
        //Echo Locally...
        pc.printf("Recieved: %s \n", temp);
        lcd.printf("Recieved %s \n", temp);
        
            
            
     //http client
     HTTPMap map;
     HTTPText inText(str, 512);
     map.put("id",id);
     map.put("data",temp);
    
    printf("\nSending Post...\n");
    ret = http.post("http://192.168.137.1/floodAlert/process.php", map, &inText);
    }
}