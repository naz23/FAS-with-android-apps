#ifndef XBee_conf_h
#define XBee_conf_h

//#define ENABLE_XBEE_WIFI

#endif

