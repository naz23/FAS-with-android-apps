#include "mbed.h"
 
Serial pc(USBTX, USBRX); // tx, rx
Serial xbee(p9, p10); // tx, rx
 
int main() {
 
    pc.printf("begin\r");
 
    for (;;) {
        if (pc.readable()) xbee.putc(pc.getc());
        if (xbee.readable()) pc.putc(xbee.getc());
    }
}