
#include "mbed.h"
#include "xbee.h" 

xbee xbee1(p9,p10,p11); //Initalise xbee_lib varName(rx,tx,reset)


DigitalIn Pin5(p5);
DigitalIn Pin6(p6);
DigitalIn Pin7(p7);

DigitalOut led_increase(LED1);
DigitalOut led_warning(LED2);
DigitalOut led_danger(LED3);


int main() {
 char *Increase;
 char *Danger;
 char *warning;

 
 while(1){
 
       if(Pin5 && !Pin6 && !Pin7){
            led_increase = 1;
            Increase = "001";
            xbee1.SendData(Increase);
            wait(5.0);
            led_increase = 0;
      }
    
       if(Pin5 && Pin6 && !Pin7){
            led_warning = 1;
            warning  = "010";
            xbee1.SendData(warning);
            wait(5.0);
            led_warning = 0;
       
      }
    

       if(Pin5 && Pin6 && Pin7){
            led_danger = 1;
            Danger= "011";
            xbee1.SendData(Danger);
            wait(5.0);
            led_danger = 0;
      }   


   }        
       
}
    
    